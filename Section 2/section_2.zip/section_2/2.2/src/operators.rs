

let addition = 2 + 2;
let subtraction = 4 - 3;
let multiplication = 2 * 2;
let division = 4 / 2;
let remainder = 4 % 2;