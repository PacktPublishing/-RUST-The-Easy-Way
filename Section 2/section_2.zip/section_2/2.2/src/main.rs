fn main() {
	let tup: (u8, i8, f32) = (1, -1, 3.5);
}
