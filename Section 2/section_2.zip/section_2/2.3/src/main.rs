fn main() {
	
	let name = "Alex";

	match name {
		"Dave" => println!("Oh hiya Dave!"),
		"Sally" => println!("Hi Sally!"),
		_ => println!("Wait, I don't know you!")
	}


	//loop {
	//	println!("Rust\n");
	//}

	//for x in 0..10{
	//	println!("{}", x);
	//}

	//let mut counter = 1;
	//while counter != 10 {
	//	println!("Counter: {}", counter);

	//	counter = counter + 1;
	//}
}
