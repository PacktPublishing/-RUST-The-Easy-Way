fn main() {

	let mut string1: String = String::new();

	string1 = "String".to_string();

	let string2 = &string;

	println!("{:?}", string);
	
	println!("{:?}", string2);

}
