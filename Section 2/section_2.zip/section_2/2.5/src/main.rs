fn main() {
    let x = 1;
    {
    	let y = 2;

    	println!("x is: {} and y is: {}", x, y);

    }

}
