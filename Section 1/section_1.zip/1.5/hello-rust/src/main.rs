fn main() {
	let text = "Hello, Rust!";
    println!("{}", text);
}
