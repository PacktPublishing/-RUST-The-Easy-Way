pub fn say_hello(){
		println!("hello!");
	}